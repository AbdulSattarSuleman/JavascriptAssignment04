var inputNumber = prompt("Enter Number ",12312.1231);
document.write("<h3>Number: "+inputNumber);
document.write("<br>Round Off value: "+Math.round(inputNumber));
document.write("<br>Floor: "+Math.floor(inputNumber));
document.write("<br>Ceil: "+Math.ceil(inputNumber)+"</h3>");
