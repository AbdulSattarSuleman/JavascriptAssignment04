var number= "472";
document.write("<h1><br>Value : "+number);
document.write("<br>Type : "+typeof(number));
var newNumber = parseInt(number);
document.write("<br>Value : "+newNumber);
document.write("<br>Type : "+typeof(newNumber));