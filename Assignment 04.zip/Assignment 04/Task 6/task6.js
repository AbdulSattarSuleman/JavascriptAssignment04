
//Randon Number dice game 
var random = Math.random();
var dice = random*6;
document.write("<br><h1>Random Dice Value: "+Math.ceil(dice));
