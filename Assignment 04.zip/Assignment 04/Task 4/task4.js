var emailStandard = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,4}$/;
var inputEmail = prompt("Enter Your Email ");

if(inputEmail.match(emailStandard)){
    alert("Valid Email :  "+inputEmail);
}
else{
    alert("Invalid Email :  "+inputEmail);
}
