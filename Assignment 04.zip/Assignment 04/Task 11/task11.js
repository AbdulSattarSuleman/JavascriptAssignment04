var userInputNumber =[];
userInputNumber = prompt("Ente Number");

var sum=0;
var totalLengthArray = userInputNumber.length;
document.write(totalLengthArray);
for(var i = 0 ; i < userInputNumber.length;i++){
            sum=userInputNumber[i]+sum;
}
var mean = (sum/totalLengthArray);
document.write("<br>Mean Value "+mean);