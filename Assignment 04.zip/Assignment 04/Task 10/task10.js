

var inputNumber = parseFloat(prompt("Enter Number "));


var afterDecimal = parseInt(prompt("How Many Number After Decimal Point"));
document.write("<h2>Input Number Is : "+inputNumber);
document.write("<br>How Many Number shown After Decimal Point :  "+afterDecimal);
document.write("<br> Number With Decimal Point"+inputNumber.toFixed(afterDecimal));
