var pwd = /^[a-zA-Z]+[a-zA-Z0-9]{8,}$/;
//("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");
//var pwdNumber = /^[0-9]+$/;
var inputPassword = prompt("Enter Password ");
if(inputPassword.match(pwd)){
    alert("Valid Password "+inputPassword);
}
else{
    alert(" InValid Password "+inputPassword);
}