var city = "Hyderabad";
var updateCity = city.replace("Hyder","Islam");
document.write("<h2>City: "+city);
document.write("<br>After Replacement: "+updateCity);