var text = "The quick brown fox jumps over the lazy dog";
document.write("<h2>Text : "+text);

document.write("<br>There are "+text.match(/the|The/g).length+" occurence of word "+"'the'");
document.write("<br>There are "+C+" occurence of word "+"'the'");
document.write("<br>"+count("The quick brown fox jumps over the lazy dog",'the',true));
